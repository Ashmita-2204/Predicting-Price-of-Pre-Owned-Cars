# Predicting-Price-of-Pre-owned-cars-Data-Science-
This project is solution to data science problem based on regression model to predict the price of pre owned cars. Programming language used is Python.
